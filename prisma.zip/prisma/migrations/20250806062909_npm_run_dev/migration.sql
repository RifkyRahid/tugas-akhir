/*
  Warnings:

  - You are about to drop the column `tes` on the `Attendance` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Attendance" DROP COLUMN "tes";

-- AlterEnum
ALTER TYPE "AttendanceStatus" ADD VALUE 'pending';

/*
  Warnings:

  - You are about to drop the column `notes` on the `Attendance` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Attendance" DROP COLUMN "notes",
ADD COLUMN     "keterangan" TEXT;

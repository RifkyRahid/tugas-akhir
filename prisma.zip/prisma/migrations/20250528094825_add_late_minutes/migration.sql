-- AlterTable
ALTER TABLE "Attendance" ADD COLUMN     "lateMinutes" INTEGER;

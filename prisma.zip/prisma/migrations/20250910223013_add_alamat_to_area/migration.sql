-- AlterTable
ALTER TABLE "public"."AttendanceArea" ADD COLUMN     "alamat" TEXT;

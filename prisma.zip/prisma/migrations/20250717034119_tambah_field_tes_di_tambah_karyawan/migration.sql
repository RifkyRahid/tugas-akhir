-- AlterTable
ALTER TABLE "Attendance" ADD COLUMN     "tes" TEXT;
